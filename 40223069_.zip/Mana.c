//Mana Lotfi
//40223069
#include <stdio.h>
#include <math.h>
double solver(double a,double b,double c);
int main()
{
  double a,b,c;
  printf("Enter three numbers: ");
  scanf("%lf %lf %lf",&a,&b,&c);
  double delta=(b*b)-(4*a*c);
  if(a==0&&b==0)
  printf("ERROR!");
  else
  {
    if(delta>0)
    {
        printf("This equation has two roots:  ");
        printf("x1=%f,x2=%f",solver(a,b,c));
    }
    if(delta==0)
    {
        printf("This equation has one root:  ");
        printf("x=%f",solver(a,b,c));
    }
    if(delta<0)
        printf("This equation has no real roots!");    
  }
}
double solver(double a,double b,double c)
{
    double delta=(b*b)-(4*a*c);
    if(delta>0)
    {
        double x1,x2;
        x1=(-b+sqrt(delta))/(2*a);
        x2=(-b-sqrt(delta))/(2*a);
        return x1;
        return x2;
    }
    if(delta==0)
    {
        double x;
        x=-b/(2*a);
        return x;
    }
}













































