//Mana Lotfi
//40223069
#include <stdio.h>
int main()
{
    int n;
    char str[n];
    printf("ENTER A NUMBER: ");
    scanf("%d",&n);
    printf("ENTER YOUR CHARACTERS: ");
    for(int i=0;i<=n;i++)
    scanf("%c",&str[i]);
    for(int i=0;i<=n;i++)
    {
        if(str[i]==str[i+1])
        {
            str[i+1]='\0';
            for(int i=0;i<=n;i++)
            printf("%c",str[i]);
        }
        else
        ;
    }
}










































